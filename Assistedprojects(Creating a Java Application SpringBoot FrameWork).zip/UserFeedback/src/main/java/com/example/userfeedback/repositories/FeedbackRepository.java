package com.example.userfeedback.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.userfeedback.entities.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback, Integer>{

}