import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

import com.example.Authentication;

public class AuthenticationTest {
    private Authentication authentication;

    @Before
    public void setUp() {
        authentication = new Authentication();
    }

    @Test
    public void testValidUserAuthentication() {
        boolean result = authentication.authenticate("validUser", "validPassword");
        assertTrue(result);
    }

    @Test
    public void testInvalidUserAuthentication() {
        boolean result = authentication.authenticate("invalidUser", "invalidPassword");
        assertFalse(result);
    }
}